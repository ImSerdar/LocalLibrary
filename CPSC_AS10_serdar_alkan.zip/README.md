# LocalLibrary
Local Library website written in Express (Node)
